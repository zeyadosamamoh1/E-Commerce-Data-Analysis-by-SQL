select*
from customers_clean2
order by 1;

select*
from products_clean2
order by 1;

select*
from orders_clean2
order by 1;

select*
from order_items_clean2
order by 1;

-------------------------------------------------------------------------------------------------------------------
-- 1) Sales Overview

-- Total revenue (quantity x unit price)
select sum(quantity * unit_price) as Total_Revenue
from order_items_clean2;


-- Total Number of Orders
select count(distinct order_id) as Total_Number_of_Orders
from orders_clean2;


-- Average Order value
select avg(Each_order_total) as Average_Order_Value
from(
select order_id, sum(quantity*unit_price) as Each_order_total
from order_items_clean2
group by order_id) as s;



-----------------------------------------------------------------------------------------------------------------------
-- 2) Customer Analysis

-- Total Number of customers
select count(distinct customer_id) as Total_Customers
from customers_clean2;


-- Top Customers by total spending
select c.customer_id, c.customer_name, 
sum(oi.quantity * oi.unit_price) as Total_Spend
from customers_clean2 as c
join orders_clean2 as o
	on c.customer_id = o.customer_id
join order_items_clean2 as oi
	on o.order_id = oi.order_id
group by c.customer_id, c.customer_name
order by 3 DESC
limit 10;


-- Number of orders per customer
select customer_id,count(order_id) as Number_of_orders
from orders_clean2
group by customer_id;





----------------------------------------------------------------------------------------------------------------------
-- 3) Product Analysis

-- Best selling products (by quantity)
select p.product_id,p.product_name,sum(oi.quantity) as total_quantity
from products_clean2 as p
join order_items_clean2 as oi
on p.product_id = oi.product_id
group by p.product_id,p.product_name
order by 3
limit 10;


-- Top Categories by revenue
select p.category , sum(oi.quantity * oi.unit_price) Total_Revenue
from products_clean2 as p
join order_items_clean2 as oi
on p.product_id = oi.product_id
group by p.category
order by 2 desc;


-- Least selling products
select p.product_id, p.product_name , sum(oi.quantity) as Total_Quantity
from products_clean2 as p
join order_items_clean2 as oi
on p.product_id = oi.product_id
group by p.product_id, p.product_name
order by 3 asc
limit 10;





----------------------------------------------------------------------------------------------------------------------
-- 4) Time Based Analysis

-- Monthly Sales
select date_format(o.order_date , '%Y-%m') as Months, sum(oi.quantity * oi.unit_price) as Monthly_Sales
from orders_clean2 as o
join order_items_clean2 as oi
on o.order_id = oi.order_id
group by months
order by 1 asc;


-- Daily Sales
select o.order_date , sum(oi.quantity * oi.unit_price) as Daily_sales
from orders_clean2 as o
join order_items_clean2 as oi
on o.order_id = oi.order_id
group by o.order_date
order by 1;


-- Peak Sales Days (TOP 10)
select o.order_date , sum(oi.quantity * oi.unit_price) as Daily_sales
from orders_clean2 as o
join order_items_clean2 as oi
on o.order_id = oi.order_id
group by o.order_date
order by 2 desc
limit 10;

